export const CHANGE_INPUT = 'changInput'
export const ADD_ITEM = 'onAddItem'
