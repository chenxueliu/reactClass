export const LOGIN = '登陆'
export const REGISTER = '注册'
